package org.ldv.savonapi.dto

class LigneIngredientDTO (
    var ingredientId:Long,
    var recetteId:Long?,
    var quantite:Float,
    var pourcentage:Float,
){
}